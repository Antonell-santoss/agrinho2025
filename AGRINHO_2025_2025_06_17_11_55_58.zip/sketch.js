// --- Global Variables ---
let totalElements = 0; // A counter to simulate changes in connection
let ruralElements = []; // Array to store elements representing the countryside
let cityElements = [];  // Array to store elements representing the city

// --- Setup Function ---
// This runs once when the sketch starts.
function setup() {
  createCanvas(900, 500); // Canvas size
}

// --- Draw Function ---
// This runs continuously, about 60 times per second.
function draw() {
  // Calculate background color based on 'totalElements'
  let backgroundColor = lerpColor(
    color(135, 206, 235), // Light blue (sky/clear connection)
    color(169, 169, 169), // Grey (city/denser connection)
    map(totalElements, 0, 100, 0, 1) // Adjust 0-100 to your desired range for 'totalElements'
  );
  background(backgroundColor); // Set the calculated background color

  // Draw the ground plane FIRST, so other elements appear on top of it.
  drawGround();

  // Display rural and city elements (if you create classes for them)
  // ruralElements.forEach(element => element.show());
  // cityElements.forEach(element => element.show());

  // Show the fixed emojis and text
  showInformation();
}

// --- Function: drawGround ---
// Draws a rectangular "ground" at the bottom of the canvas.
function drawGround() {
  let groundHeight = 100; // Adjust this to make the ground thicker or thinner
  let groundColor = color(124, 201, 74); // A nice green for grass (RGB)

  noStroke(); // No border for the ground rectangle
  fill(groundColor); // Set the ground color
  rect(0, height - groundHeight, width, groundHeight); // Draw the rectangle
}

// --- Helper Function: showInformation ---
// This function draws all the emojis and text on the canvas.
function showInformation() {
  // City Emojis
  textSize(190);
  fill(0); // Black color for text
  text('🏙️', 30, 430); // Adjusted position to be visible on the ground

 textSize (90)
  fill(0);
  text('🏡', 250, 430);
  text('🏡', 350, 430);
  textSize (110);
  text ('☀️', 50, 120);
   text ('☁️' ,250,120);
  text ('☁️' ,650,120)
   text ('☁️' ,450,120);
  // Connection Emojis (people/animals moving between)
  textSize(50);
  fill(0);
  text('🏃‍♀️', 450, 440);
  text('🐎', 520, 430);
   text('🐂', 500, 460);
   text('🐄', 520, 490);

  // Rural Emojis
  textSize(90);
  fill(0);
  text('🚜', 600, 435);
  text('🌳', 830, 460);
  text('🌳', 800, 460);
  text('🌳', 770, 460);
  text('🌳', 730, 460);
  text('🌳', 690, 460);
  text('🌳', -25, 450);
  
}

// --- Key Pressed Function ---
// This function runs whenever a key is pressed.
function keyPressed() {
  if (key === 'C' || key === 'c') {
    // Add an element to the rural side (e.g., totalElements increases)
    totalElements = min(totalElements + 5, 100); // Increase, but don't go over 100
    print('Rural element added. Total elements: ' + totalElements);
  } else if (key === 'D' || key === 'd') {
    // Add an element to the city side (e.g., totalElements decreases)
    totalElements = max(totalElements - 5, 0); // Decrease, but don't go below 0
    print('City element added. Total elements: ' + totalElements);
  }
}